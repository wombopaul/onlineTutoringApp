//feather active
feather.replace()